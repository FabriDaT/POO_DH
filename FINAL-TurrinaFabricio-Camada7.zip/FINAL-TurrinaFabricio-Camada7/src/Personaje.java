public class Personaje {
    private String nombre;


    public Personaje(String nombre) {
        this.nombre = nombre;
    }

    public Personaje() {
    }
    public adquirirHabilidad(){

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void mostrar(){

    }
}
